import cartopy
import math
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
from cartopy import crs as ccrs
from cartopy.feature import ShapelyFeature
from cartopy.io.shapereader import Reader
from shapely.geometry import box
from shapely.geometry import Point, LineString
import numpy as np
import openpyxl
import cartopy.feature as cfeature
archivo = 'catalogo sismo tarea.xlsx'
df = pd.read_excel(archivo)
lat = np.array(df.iloc[:,1].values)
lon = np.array(df.iloc[:,2].values)
pro = np.array(df.iloc[:,3].values)
mag = np.array(df.iloc[:,4].values)**2*10
latpro = np.mean(lat)
lonpro = np.mean(lon)
lista1 = [{"lat":latpro, "lon":lonpro}]
lista2 = [{"lat":lat,"long":lon,"prof":pro,"mag":mag}]
fig = plt.figure(figsize=(10, 5))
ax = plt.axes(projection=ccrs.PlateCarree())  
ax.add_feature(cfeature.COASTLINE) 
ax.add_feature(cfeature.BORDERS, linestyle=':') 
ax.add_feature(cfeature.LAND, facecolor='lightgray') 
ax.add_feature(cfeature.OCEAN, facecolor='lightblue') 
ax.set_global() 
min_lon_ = lonpro - 0.3
min_lat_ = latpro - 0.3
max_lon_ = lonpro + 0.3
max_lat_ = latpro + 0.3
ax.set_extent([min_lon_,max_lon_,min_lat_,max_lat_], crs = ccrs.PlateCarree())
ax.set_title("Mapa Sismo Choco - 27/08/2023 - lat = 5,376 - long = -76,76", fontsize=14)
for y in lista2:
    scatter_sismos = ax.scatter(y["long"],y["lat"],c=y["prof"],cmap = "coolwarm_r",s = y["mag"],edgecolors="black", transform = ccrs.PlateCarree(),label = 'sismos')
plt.colorbar(scatter_sismos,ax = ax, label = 'Profundidad (Km)')
gridlines = ax.gridlines(draw_labels=True, linestyle='--', color='gray', alpha=0.7)
gridlines.top_labels = False
gridlines.right_labels = False 
gridlines.xlabel_style = {'size': 10, 'color': 'black'}
gridlines.ylabel_style = {'size': 10, 'color': 'black'}
plt.show()
